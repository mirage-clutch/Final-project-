# Online Gaming Anxiety - Code Folder

This folder contains the Python code and dataset used for analysis.

Contents:
- Online_Gaming_Anxiety_Analysis.ipynb  (Jupyter Notebook from Google Colab)
- online_gaming_anxiety.csv             (Original dataset)
- processed_gaming_anxiety.csv          (Cleaned data)
- [Optional] Screenshot charts from analysis

Tools Used:
- Google Colab
- Python 3.10
- Pandas, Matplotlib, Seaborn

Instructions:
1. Open the .ipynb file using Google Colab.
2. Upload the dataset when prompted.
3. Run the notebook step-by-step to reproduce all visualizations.

